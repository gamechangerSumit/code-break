package com.codebreak.backend.websocket;

import com.codebreak.backend.project.ProjectMemberService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.security.Principal;

@Controller
@RequiredArgsConstructor
public class CollaborationController {

    private final SimpMessagingTemplate messagingTemplate;

    private final ProjectMemberService projectMemberService;

    private final WorkspaceStore workspaceStore;


    // =====================================================
    // CODE EDIT
    // =====================================================

    @MessageMapping("/edit")
    public void edit(
            CollaborationMessage message,
            Principal principal
    ) {

        if (
                message == null ||
                        principal == null ||
                        message.getProjectId() == null ||
                        message.getFilePath() == null
        ) {
            return;
        }


        String username =
                principal.getName();


        projectMemberService.requireWriteAccess(
                message.getProjectId(),
                username
        );


        message.setUsername(
                username
        );


        workspaceStore.putFile(
                message.getProjectId(),
                message.getFilePath(),
                message.getContent()
        );


        messagingTemplate.convertAndSend(
                "/topic/project/"
                        + message.getProjectId()
                        + "/code",
                message
        );
    }


    // =====================================================
    // WORKSPACE
    // =====================================================

    @MessageMapping("/workspace")
    public void workspace(
            CollaborationMessage message,
            Principal principal
    ) {

        if (
                message == null ||
                        principal == null ||
                        message.getProjectId() == null
        ) {
            return;
        }


        String username =
                principal.getName();


        projectMemberService.requireWriteAccess(
                message.getProjectId(),
                username
        );


        message.setUsername(
                username
        );


        String type =
                message.getType();


        if (type == null) {
            return;
        }


        // =================================================
        // COMPLETE WORKSPACE
        // =================================================

        if (
                "WORKSPACE_SYNC".equals(type)
        ) {

            int fileCount =
                    message.getFiles() == null
                            ? 0
                            : message.getFiles().size();


            int folderCount =
                    message.getFolders() == null
                            ? 0
                            : message.getFolders().size();


            System.out.println(
                    "[WS WORKSPACE] COMPLETE SYNC received: "
                            + "Project="
                            + message.getProjectId()
                            + " User="
                            + username
                            + " Files="
                            + fileCount
                            + " Folders="
                            + folderCount
            );


            workspaceStore.replaceWorkspace(
                    message.getProjectId(),
                    message.getFiles(),
                    message.getFolders()
            );


            /*
             * Existing collaborators ko workspace event
             * broadcast kar do.
             *
             * Sender khud isko ignore karega because
             * frontend username match check karta hai.
             */

            messagingTemplate.convertAndSend(
                    "/topic/project/"
                            + message.getProjectId()
                            + "/workspace",
                    message
            );


            return;
        }


        // =================================================
        // SINGLE FILE
        // =================================================

        if (
                "WORKSPACE_FILE".equals(type)
        ) {

            if (
                    message.getFilePath() == null ||
                            message.getFilePath().isBlank()
            ) {
                return;
            }


            workspaceStore.putFile(
                    message.getProjectId(),
                    message.getFilePath(),
                    message.getContent()
            );


            messagingTemplate.convertAndSend(
                    "/topic/project/"
                            + message.getProjectId()
                            + "/workspace",
                    message
            );


            return;
        }


        // =================================================
        // SINGLE FOLDER
        // =================================================

        if (
                "WORKSPACE_FOLDER".equals(type)
        ) {

            if (
                    message.getFilePath() == null ||
                            message.getFilePath().isBlank()
            ) {
                return;
            }


            workspaceStore.putFolder(
                    message.getProjectId(),
                    message.getFilePath()
            );


            messagingTemplate.convertAndSend(
                    "/topic/project/"
                            + message.getProjectId()
                            + "/workspace",
                    message
            );


            return;
        }


        // =================================================
        // DELETE FILE
        // =================================================

        if (
                "WORKSPACE_DELETE".equals(type)
        ) {

            if (
                    message.getFilePath() == null ||
                            message.getFilePath().isBlank()
            ) {
                return;
            }


            workspaceStore.deleteFile(
                    message.getProjectId(),
                    message.getFilePath()
            );


            messagingTemplate.convertAndSend(
                    "/topic/project/"
                            + message.getProjectId()
                            + "/workspace",
                    message
            );


            return;
        }


        // =================================================
        // DELETE FOLDER
        // =================================================

        if (
                "WORKSPACE_FOLDER_DELETE".equals(type)
        ) {

            if (
                    message.getFilePath() == null ||
                            message.getFilePath().isBlank()
            ) {
                return;
            }


            workspaceStore.deleteFolder(
                    message.getProjectId(),
                    message.getFilePath()
            );


            messagingTemplate.convertAndSend(
                    "/topic/project/"
                            + message.getProjectId()
                            + "/workspace",
                    message
            );


            return;
        }


        System.out.println(
                "[WS WORKSPACE] Unknown type: "
                        + type
        );
    }


    // =====================================================
    // REQUEST WORKSPACE
    // =====================================================

    @MessageMapping("/workspace/request")
    public void requestWorkspace(
            WorkspaceRequest request,
            Principal principal
    ) {

        if (
                request == null ||
                        principal == null ||
                        request.projectId() == null
        ) {
            return;
        }


        String username =
                principal.getName();


        projectMemberService.requireReadAccess(
                request.projectId(),
                username
        );


        WorkspaceStore.WorkspaceSnapshot snapshot =
                workspaceStore.getSnapshot(
                        request.projectId()
                );


        System.out.println(
                "[WS SNAPSHOT] Request received: "
                        + "User="
                        + username
                        + " Project="
                        + request.projectId()
                        + " Files="
                        + snapshot.files().size()
                        + " Folders="
                        + snapshot.folders().size()
        );


        messagingTemplate.convertAndSendToUser(
                username,
                "/queue/workspace",
                snapshot
        );


        System.out.println(
                "[WS SNAPSHOT] Snapshot sent to: "
                        + username
        );
    }
}