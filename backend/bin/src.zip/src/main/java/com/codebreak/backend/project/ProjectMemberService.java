package com.codebreak.backend.project;

import com.codebreak.backend.user.User;
import com.codebreak.backend.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectMemberService {

    private final ProjectMemberRepository projectMemberRepository;

    private final UserRepository userRepository;

    private final ProjectRepository projectRepository;

    private final SimpMessagingTemplate messagingTemplate;


    // =========================================
    // GET USER
    // =========================================

    private User getUser(
            String username
    ) {

        return userRepository
                .findByUsername(username)
                .orElseThrow(() ->
                        new RuntimeException(
                                "User not found"
                        )
                );
    }


    // =========================================
    // GET PROJECT MEMBER
    // =========================================

    public ProjectMember getProjectMember(
            Long projectId,
            String username
    ) {

        User user = getUser(username);

        return projectMemberRepository
                .findByProjectIdAndUserId(
                        projectId,
                        user.getId()
                )
                .orElseThrow(() ->
                        new RuntimeException(
                                "You are not a member of this project"
                        )
                );
    }


    // =========================================
    // READ ACCESS
    // =========================================

    public void requireReadAccess(
            Long projectId,
            String username
    ) {

        getProjectMember(
                projectId,
                username
        );
    }


    // =========================================
    // WRITE ACCESS
    // =========================================

    public void requireWriteAccess(
            Long projectId,
            String username
    ) {

        ProjectMember member =
                getProjectMember(
                        projectId,
                        username
                );

        ProjectRole role =
                member.getRole();

        if (
                role != ProjectRole.OWNER &&
                        role != ProjectRole.EDITOR
        ) {

            throw new RuntimeException(
                    "You do not have permission to modify this project"
            );
        }
    }


    // =========================================
    // JOIN PROJECT
    // =========================================

    public ProjectMember joinProject(
            String joinCode,
            String username
    ) {

        if (
                joinCode == null ||
                        joinCode.isBlank()
        ) {

            throw new RuntimeException(
                    "Join code is required"
            );
        }


        User user =
                getUser(username);


        String normalizedCode =
                joinCode
                        .trim()
                        .toUpperCase();


        Project project =
                projectRepository
                        .findByJoinCode(
                                normalizedCode
                        )
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Invalid join code"
                                )
                        );


        // =====================================
        // OWNER CANNOT JOIN OWN PROJECT
        // =====================================

        if (
                project.getOwner()
                        .getId()
                        .equals(user.getId())
        ) {

            throw new RuntimeException(
                    "You are already the owner of this project"
            );
        }


        // =====================================
        // ALREADY MEMBER
        // =====================================

        if (
                projectMemberRepository
                        .existsByProjectIdAndUserId(
                                project.getId(),
                                user.getId()
                        )
        ) {

            throw new RuntimeException(
                    "You are already a member of this project"
            );
        }


        // =====================================
        // NEW MEMBERS START AS VIEWER
        // =====================================

        ProjectMember member =
                ProjectMember.builder()
                        .project(project)
                        .user(user)
                        .role(ProjectRole.VIEWER)
                        .build();


        return projectMemberRepository.save(
                member
        );
    }


    // =========================================
    // GET PROJECT MEMBERS
    // =========================================

    public List<ProjectMemberResponse>
    getProjectMembers(
            Long projectId,
            String username
    ) {

        requireReadAccess(
                projectId,
                username
        );

        return projectMemberRepository
                .findByProjectId(projectId)
                .stream()
                .map(member ->
                        new ProjectMemberResponse(
                                member.getId(),
                                member.getUser().getId(),
                                member.getUser().getUsername(),
                                member.getRole()
                        )
                )
                .toList();
    }


    // =========================================
    // CHANGE MEMBER ROLE
    // =========================================

    public ProjectMemberResponse changeRole(
            Long projectId,
            Long memberId,
            ProjectRole newRole,
            String username
    ) {

        // =====================================
        // CURRENT USER
        // =====================================

        ProjectMember currentUser =
                getProjectMember(
                        projectId,
                        username
                );


        // =====================================
        // ONLY OWNER CAN CHANGE ROLES
        // =====================================

        if (
                currentUser.getRole()
                        != ProjectRole.OWNER
        ) {

            throw new RuntimeException(
                    "Only the project owner can change member roles"
            );
        }


        // =====================================
        // FIND MEMBER
        // =====================================

        ProjectMember member =
                projectMemberRepository
                        .findById(memberId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Member not found"
                                )
                        );


        // =====================================
        // SECURITY CHECK
        // =====================================

        if (
                !member.getProject()
                        .getId()
                        .equals(projectId)
        ) {

            throw new RuntimeException(
                    "Member does not belong to this project"
            );
        }


        // =====================================
        // OWNER ROLE CANNOT CHANGE
        // =====================================

        if (
                member.getRole()
                        == ProjectRole.OWNER
        ) {

            throw new RuntimeException(
                    "The owner role cannot be changed"
            );
        }


        // =====================================
        // VALIDATE ROLE
        // =====================================

        if (
                newRole == null ||
                        newRole == ProjectRole.OWNER
        ) {

            throw new RuntimeException(
                    "Invalid member role"
            );
        }


        // =====================================
        // UPDATE ROLE
        // =====================================

        member.setRole(
                newRole
        );


        ProjectMember saved =
                projectMemberRepository.save(
                        member
                );


        // =====================================
        // RESPONSE
        // =====================================

        ProjectMemberResponse response =
                new ProjectMemberResponse(
                        saved.getId(),
                        saved.getUser().getId(),
                        saved.getUser().getUsername(),
                        saved.getRole()
                );


        // =====================================
        // REALTIME ROLE BROADCAST
        // =====================================

        ProjectRoleChangedMessage message =
                new ProjectRoleChangedMessage(

                        saved.getProject().getId(),

                        saved.getId(),

                        saved.getUser().getId(),

                        saved.getUser().getUsername(),

                        saved.getRole()

                );


        messagingTemplate.convertAndSend(
                "/topic/project/"
                        + projectId
                        + "/members",
                message
        );


        return response;
    }
}