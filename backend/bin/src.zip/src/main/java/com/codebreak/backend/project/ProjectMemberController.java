package com.codebreak.backend.project;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projects")
@RequiredArgsConstructor
public class ProjectMemberController {

    private final ProjectMemberService projectMemberService;


    // =========================================
    // JOIN PROJECT
    // =========================================

    @PostMapping("/join")
    public ResponseEntity<ProjectMemberResponse>
    joinProject(
            @RequestBody JoinProjectRequest request,
            Authentication authentication
    ) {

        ProjectMember member =
                projectMemberService.joinProject(
                        request.joinCode(),
                        authentication.getName()
                );


        ProjectMemberResponse response =
                new ProjectMemberResponse(
                        member.getId(),
                        member.getUser().getId(),
                        member.getUser().getUsername(),
                        member.getRole()
                );


        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }


    // =========================================
    // GET MEMBERS
    // =========================================

    @GetMapping("/{projectId}/members")
    public ResponseEntity<
            List<ProjectMemberResponse>
            > getMembers(
            @PathVariable Long projectId,
            Authentication authentication
    ) {

        return ResponseEntity.ok(
                projectMemberService
                        .getProjectMembers(
                                projectId,
                                authentication.getName()
                        )
        );
    }


    // =========================================
    // CHANGE ROLE
    // =========================================

    @PutMapping(
            "/{projectId}/members/{memberId}/role"
    )
    public ResponseEntity<ProjectMemberResponse>
    changeRole(
            @PathVariable Long projectId,
            @PathVariable Long memberId,
            @RequestParam ProjectRole role,
            Authentication authentication
    ) {

        return ResponseEntity.ok(
                projectMemberService.changeRole(
                        projectId,
                        memberId,
                        role,
                        authentication.getName()
                )
        );
    }
}