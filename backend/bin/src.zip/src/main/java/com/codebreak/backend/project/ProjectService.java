package com.codebreak.backend.project;

import com.codebreak.backend.user.User;
import com.codebreak.backend.user.UserRepository;
import com.codebreak.backend.websocket.WorkspaceStore;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepository;

    private final UserRepository userRepository;

    private final ProjectMemberRepository projectMemberRepository;

    private final WorkspaceStore workspaceStore;


    // =========================================
    // CREATE PROJECT
    // =========================================

    public ProjectResponse createProject(
            ProjectRequest request,
            String username
    ) {

        User owner =
                userRepository
                        .findByUsername(username)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User not found"
                                )
                        );


        Project project =
                Project.builder()
                        .name(request.name())
                        .description(request.description())
                        .owner(owner)
                        .build();


        Project savedProject =
                projectRepository.save(project);


        // =====================================
        // ADD OWNER AS MEMBER
        // =====================================

        ProjectMember ownerMember =
                ProjectMember.builder()
                        .project(savedProject)
                        .user(owner)
                        .role(ProjectRole.OWNER)
                        .build();


        projectMemberRepository.save(
                ownerMember
        );


        return new ProjectResponse(
                savedProject.getId(),
                savedProject.getName(),
                savedProject.getDescription(),
                savedProject.getJoinCode()
        );
    }


    // =========================================
    // GET USER PROJECTS
    // =========================================

    public List<ProjectResponse> getUserProjects(
            String username
    ) {

        User user =
                userRepository
                        .findByUsername(username)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "User not found"
                                )
                        );


        // =====================================
        // OWNED PROJECTS
        // =====================================

        List<Project> ownedProjects =
                projectRepository
                        .findByOwnerId(
                                user.getId()
                        );


        // =====================================
        // MEMBER PROJECTS
        // =====================================

        List<Project> memberProjects =
                projectMemberRepository
                        .findByUserId(
                                user.getId()
                        )
                        .stream()
                        .map(ProjectMember::getProject)
                        .toList();


        // =====================================
        // COMBINE WITHOUT DUPLICATES
        // =====================================

        Map<Long, Project> projects =
                new LinkedHashMap<>();


        for (Project project :
                ownedProjects) {

            projects.put(
                    project.getId(),
                    project
            );
        }


        for (Project project :
                memberProjects) {

            projects.put(
                    project.getId(),
                    project
            );
        }


        // =====================================
        // RESPONSE
        // =====================================

        return projects
                .values()
                .stream()
                .map(project -> {

                    boolean isOwner =
                            project.getOwner()
                                    .getId()
                                    .equals(user.getId());


                    return new ProjectResponse(
                            project.getId(),
                            project.getName(),
                            project.getDescription(),

                            // Only owner receives code
                            isOwner
                                    ? project.getJoinCode()
                                    : null
                    );
                })
                .toList();
    }


    // =========================================
    // DELETE PROJECT
    // OWNER ONLY
    // =========================================

    @Transactional
    public void deleteProject(
            Long projectId,
            String username
    ) {

        User user =
                userRepository
                        .findByUsername(username)
                        .orElseThrow(() ->
                                new ResponseStatusException(
                                        HttpStatus.UNAUTHORIZED,
                                        "User not found"
                                )
                        );


        Project project =
                projectRepository
                        .findById(projectId)
                        .orElseThrow(() ->
                                new ResponseStatusException(
                                        HttpStatus.NOT_FOUND,
                                        "Project not found"
                                )
                        );


        // =====================================
        // OWNER CHECK
        // =====================================

        if (
                project.getOwner() == null ||
                        project.getOwner().getId() == null ||
                        !project.getOwner()
                                .getId()
                                .equals(user.getId())
        ) {

            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Only the project owner can delete this project."
            );
        }


        // =====================================
        // CLEAR EPHEMERAL WORKSPACE
        // =====================================

        workspaceStore.clearProject(
                projectId
        );


        // =====================================
        // DELETE ALL MEMBERS
        // =====================================

        projectMemberRepository.deleteByProjectId(
                projectId
        );


        // =====================================
        // DELETE PROJECT
        // =====================================

        projectRepository.delete(
                project
        );
    }
}